const express = require('express');
const app = express();
const session = require('express-session');
app.use(session({secret:'john'}));
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use(express.static('pages'));

app.get('/', function(req, res){
   res.sendFile(__dirname +"/pages/login.html")
});

app.get('/index', function (req, res){
    if (req.session.visited==false || req.session.visited == undefined)
    {
        res.send('Error, Please Login Before Going To HomePage');
    }
    else
    {
        res.sendFile(__dirname + '/pages/homepage.html');
    }
});

app.get('/login', function (req, res){
    if (req.session.visited)
    {
        res.send("You Are Already Logged In");
    }
    else
    {
        res.sendFile(__dirname + '/pages/login.html');
    }
});

app.post('/login', function (req, res){
    if(req.body.username == 'sandy' && req.body.userpassword == '1111')
    {
        req.session.visited = true;
        res.redirect('/index') 
    }
    else
    {
        // res.send('Warning! , Please Login With Your Credentials.')
        throw new Error('Warning! , Please Login With Your Credentials.')
    }
});

app.get('/logout', function(req, res)
{
    req.session.visited = false;
    res.redirect('/login')
});


app.listen(3000, ()=> console.log('Started'));

